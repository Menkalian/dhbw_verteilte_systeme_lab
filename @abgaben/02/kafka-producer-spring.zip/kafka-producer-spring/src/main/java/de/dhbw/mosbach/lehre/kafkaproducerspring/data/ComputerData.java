package de.dhbw.mosbach.lehre.kafkaproducerspring.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ComputerData {
    private double freeMem;
}
