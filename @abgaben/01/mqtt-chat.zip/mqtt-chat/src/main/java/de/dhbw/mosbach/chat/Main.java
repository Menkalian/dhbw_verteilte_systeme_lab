package de.dhbw.mosbach.chat;

public class Main {
    public static void main(String[] args) {
        Connector connector = new Connector();
    }
}
