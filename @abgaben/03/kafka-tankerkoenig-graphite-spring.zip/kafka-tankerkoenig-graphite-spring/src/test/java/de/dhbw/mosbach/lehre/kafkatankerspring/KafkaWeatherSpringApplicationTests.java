package de.dhbw.mosbach.lehre.kafkatankerspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaWeatherSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
